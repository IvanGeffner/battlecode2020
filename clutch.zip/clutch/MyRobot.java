package clutch;

public abstract class MyRobot {

    abstract void play();

    int add(int i, int j){
        return i+j;
    }

}
