package rush;

public abstract class MyRobot {

    abstract void play();

}
