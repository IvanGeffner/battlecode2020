package antidrones;

import battlecode.common.RobotController;

public class Refinery extends MyRobot {

    RobotController rc;

    Refinery(RobotController rc){
        this.rc = rc;
    }

    void play(){

    }

}
