package antidrones;

import battlecode.common.RobotController;

public class Vaporator extends MyRobot {

    RobotController rc;

    Vaporator(RobotController rc){
        this.rc = rc;
    }

    void play(){

    }

}
